Charachter/symbol drawing application for image recognition
